<?php 
	include_once 'conexion.php';
	if(isset($_POST['contrasena']) && isset($_POST['email'])){
		$graduado = $con->consulta("*","graduados","id='".$_POST['contrasena']."' and correo ='".$_POST['email']."'");
		if (sizeof($graduado)<=0) {
			header("Location: index.php");
			exit();
		}
	}	
?>
<!DOCTYPE html>
<html>
<head>
<title>Fiesta</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
</head>
<body class="bg-agileinfo">
   <h1 class="agile-head text-center" >Graduación 17/Agosto/2019</h1>
	<div class="container-w3">
		<div class="w3ls-subhead">
			<i class="fa fa-clock-o" aria-hidden="true"></i>
		</div>
		<h2 style="background: lightblue">
		<?php
			if(!isset($_POST['contrasena']) && !isset($_POST['email'])){
			 ?>Pronto...!
		<?php } else { ?>
		
		<?php echo $graduado[0]->nombre. " ".$graduado[0]->apellidos; } ?>

		</h2>
		<div class="demo2"></div>
		<div class="content2-w3-agileits">
			<?php
			if(!isset($_POST['contrasena']) && !isset($_POST['email'])){
			 ?>
			   <form action="index.php" method="post" class="agile-info-form">
					<input type="email"  class="email" name="email" placeholder="Escribe tu Correo"   required="">
					<input type="password" class="email" name="contrasena" placeholder="Contraseña"   required="">
				
					<input type="submit" value="Entrar!">
				</form>	


			<hr>
			<br>
			<?php } else{ ?>
			<?php } ?>
		</div>
		<div class="wthree-social-icons">
			<ul class="w3-links">
				
			</ul>
		</div>
	</div>	
    <div class="agileits-w3layouts-copyright text-center">
		<!--<p>© 2017 Inventive. All rights reserved | Design by <a href="//w3layouts.com/">W3layouts</a></p>-->
	</div>
	
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->

	<link rel="stylesheet" href='css/dscountdown.css' type='text/css' media='all' />
	<!-- Counter required files -->
		<script type="text/javascript" src="js/dscountdown.min.js"></script>
		<script>
			jQuery(document).ready(function($){						
				$('.demo2').dsCountDown({
					endDate: new Date("augost 17, 2019 20:00:00"),
					theme: 'black',
					titleDays:'Dias',
					titleHours:'Horas',
					titleMinutes:'Minutos',
					titleSeconds:'Segundos',
				});								
			});
		</script>
		<script type="text/javascript">
			$(".ds-element-days ds-element-title").html("Dias");
			
		</script>
	<!-- //Counter required files -->
</body>
</html>